import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../../../services/common.service';
import { ValidationsService } from '../../../services/validations.service';
import { EmailTemplateService } from './email-template.service';

@Component({
  selector: 'app-email-template',
  templateUrl: './email-template.component.html',
  styleUrls: ['./email-template.component.scss']
})
export class EmailTemplateComponent implements OnInit {

  public emaitemplateIdid: String;
  public name: String;
  public description: String;
  public status: Boolean;
  public emailTemplateList:String;

  constructor(
    private activatedRoute: ActivatedRoute,
    private _commonService: CommonService,
    private _validationsService: ValidationsService,
    private emailtemplateService: EmailTemplateService

  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.emaitemplateIdid = params['featureid'];
      if (!this._validationsService.isEmpty(this.emaitemplateIdid)) {
        this.getEmailTemplateById(this.emaitemplateIdid);
      }
    });
    this.getEmailTemplateList();
  }

  getEmailTemplateList() {
    this.emailtemplateService.getEmailTemplate()
        .subscribe(res => {
            this.emailTemplateList = res.data;
            // console.log(this.trainingHeadList);
        });
}

  getEmailTemplateById(emaitemplateIdid: any) {
    this.emailtemplateService.getEmailTemplateById(emaitemplateIdid)
      .subscribe(res => {
        this.name = res.data.name;
        this.description = res.data.description;
        this.status = res.data.status;
        this.emaitemplateIdid = res.data._id;
      });
  }

  editEmailTemplate(Emailhead: any) {
    // this._commonService.redirectTo(`/admin/training/edit/${Traininghead._id}`);
    this.emaitemplateIdid = Emailhead._id;
    this.name = Emailhead.name;
    this.description = Emailhead.description;
    window.scrollTo(0, 0);
}

deleteEmailTemplate(Emailheadid: any) {
    this.emailtemplateService.deleteEmailTemplate(Emailheadid)
        .subscribe(res => {
            if (res.success) {
                this._commonService.showMessage('success', res.msg);
                this.name = '';
                this.getEmailTemplateList();
            } else {
                this._commonService.showMessage('error', res.msg);
            }
        });
}

  emailTemplateForm() {
    if (this._validationsService.isEmpty(this.name)) {
      this._commonService.showMessage('error', 'Name field should not be empty!');
      return false;
    }
    if (this._validationsService.isEmpty(this.description)) {
      this._commonService.showMessage('error', 'Description field should not be empty!');
      return false;
    }
    let emailTemplate;
    if (!this._validationsService.isEmpty(this.emaitemplateIdid)) {
      emailTemplate = {
        name: this.name,
        description: this.description,
        status: this.status,
        emaitemplateIdid: this.emaitemplateIdid
      };
    } else {
      emailTemplate = {
        name: this.name,
        description: this.description,
        status: this.status
      };
    }
    this.emailtemplateService.addEmailTemplate(emailTemplate)
      .subscribe(res => {
        if (res.success) {
          this._commonService.showMessage('success', res.msg);
          this.name = '';
          this.description = '';
          this.getEmailTemplateList();
          // this.status = false;
          // this._commonService.redirectTo('/admin/feature/list');
        } else {
          this._commonService.showMessage('error', res.msg);
        }
      });



  }

}
