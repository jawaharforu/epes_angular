import { MdbStickyDirective } from './sticky-content.directive';
export { MdbStickyDirective };
export declare class StickyContentModule {
}
