export declare class CardRevealComponent {
    socials: any;
    show: boolean;
    toggle(): void;
}
