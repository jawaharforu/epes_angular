export declare class CardRotatingComponent {
    rotate: boolean;
    toggle(): void;
}
