import { ModuleWithProviders } from '@angular/core';
export declare class CardsModule {
    static forRoot(): ModuleWithProviders;
}
