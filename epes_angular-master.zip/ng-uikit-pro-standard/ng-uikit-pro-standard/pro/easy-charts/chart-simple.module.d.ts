export declare class ChartSimpleModule {
}
