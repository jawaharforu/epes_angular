export declare class LightBoxModule {
}
