export declare const sbConfig: {
    serviceInstance: Object;
};
