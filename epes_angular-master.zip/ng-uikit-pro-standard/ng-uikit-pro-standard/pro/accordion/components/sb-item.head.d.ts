import { SBItemComponent } from './sb-item';
export declare class SBItemHeadComponent {
    private sbItem;
    constructor(sbItem: SBItemComponent);
    toggleClick(event: any): void;
}
