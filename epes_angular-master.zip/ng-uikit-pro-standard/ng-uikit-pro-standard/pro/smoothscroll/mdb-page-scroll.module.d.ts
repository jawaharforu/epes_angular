import { ModuleWithProviders } from '@angular/core';
export declare class SmoothscrollModule {
    static forRoot(): ModuleWithProviders;
}
