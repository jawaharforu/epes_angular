export declare const MAX_CHARS = 524288;
export declare const MIN_SEARCH_LENGTH = 3;
export declare const PAUSE = 100;
export declare const TEXT_SEARCHING = "Searching...";
export declare const TEXT_NO_RESULTS = "No results found";
export declare const CLEAR_TIMEOUT = 50;
export declare function isNil(value: string): boolean;
