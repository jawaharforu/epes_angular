export declare class AutocompleteModule {
}
