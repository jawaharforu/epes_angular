import { IMyOptions } from './options.interface';
export interface IMyLocales {
    [lang: string]: IMyOptions;
}
