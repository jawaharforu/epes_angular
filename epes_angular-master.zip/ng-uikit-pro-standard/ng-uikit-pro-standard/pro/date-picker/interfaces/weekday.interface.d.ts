export interface IMyWeekday {
    number: number;
    weekday: string;
}
