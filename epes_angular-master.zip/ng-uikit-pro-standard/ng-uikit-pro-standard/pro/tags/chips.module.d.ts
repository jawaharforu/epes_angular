export declare class MaterialChipsModule {
}
