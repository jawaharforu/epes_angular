export declare function OnChange(): any;
