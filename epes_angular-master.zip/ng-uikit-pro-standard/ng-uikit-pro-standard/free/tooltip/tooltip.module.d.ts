import { ModuleWithProviders } from '@angular/core';
export declare class TooltipModule {
    static forRoot(): ModuleWithProviders;
}
