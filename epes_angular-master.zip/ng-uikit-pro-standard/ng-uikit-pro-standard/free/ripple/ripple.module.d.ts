import { ModuleWithProviders } from '@angular/core';
export declare class RippleModule {
    static forRoot(): ModuleWithProviders;
}
