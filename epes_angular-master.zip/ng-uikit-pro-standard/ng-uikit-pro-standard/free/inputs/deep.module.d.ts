import { ModuleWithProviders } from '@angular/core';
export declare class DeepModule {
    static forRoot(): ModuleWithProviders;
}
