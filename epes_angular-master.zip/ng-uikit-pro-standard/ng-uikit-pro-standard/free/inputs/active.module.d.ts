import { ModuleWithProviders } from '@angular/core';
export declare class ActiveModule {
    static forRoot(): ModuleWithProviders;
}
